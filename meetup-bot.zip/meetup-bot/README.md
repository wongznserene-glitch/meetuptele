# 🍜 Meetup Bot — Telegram Group Meetup Planner

A full-stack Telegram bot + mobile web app that helps friend groups find the perfect restaurant to meet at.

---

## Architecture

```
meetup-bot/
├── bot/
│   └── index.js              # Telegram bot (polling or webhook)
├── backend/
│   ├── server.js             # Express + Socket.IO server
│   ├── models/
│   │   └── Session.js        # Mongoose schema
│   ├── routes/
│   │   └── api.js            # REST API endpoints
│   └── services/
│       ├── locationService.js     # Geocoding, midpoint, travel times
│       └── restaurantService.js   # Google Places search + dish extraction
├── frontend/
│   └── public/
│       ├── index.html        # mWeb app shell
│       ├── css/style.css     # Orange UI matching Figma spec
│       └── js/app.js         # All frontend logic + Socket.IO
├── .env.example
├── docker-compose.yml
└── package.json
```

---

## User Flow

```
Group chat → /meetup
    ↓
Bot posts link → https://yourapp.com/meetup/<sessionId>
    ↓
Each user opens link and fills in:
  • Location (GPS or autocomplete)
  • Available time slots
  • Cuisine preferences
  • Budget
    ↓
Host taps "Find Restaurants"
    ↓
Server computes midpoint → searches Google Places → returns top 6
    ↓
All users vote on restaurant cards (live via Socket.IO)
    ↓
Host finalises → Bot posts winner back to Telegram group
```

---

## Setup

### 1. Clone & Install

```bash
git clone <repo>
cd meetup-bot
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your keys
```

Required keys:
| Variable | Source |
|---|---|
| `TELEGRAM_BOT_TOKEN` | [@BotFather](https://t.me/botfather) → `/newbot` |
| `GOOGLE_MAPS_API_KEY` | [Google Cloud Console](https://console.cloud.google.com) — enable Maps JS API, Places API, Geocoding API, Distance Matrix API |
| `MONGODB_URI` | Local MongoDB or [MongoDB Atlas](https://mongodb.com/atlas) |
| `BASE_URL` | Your public server URL (e.g. `https://yourdomain.com`) |

### 3. Run Locally

```bash
# Terminal 1: backend
node backend/server.js

# Terminal 2: bot
node bot/index.js
```

Or together:
```bash
npm run dev
```

### 4. Deploy with Docker

```bash
docker-compose up -d
```

### 5. Expose Publicly (for Telegram)

Use [ngrok](https://ngrok.com) for local dev:
```bash
ngrok http 3000
# Copy the https URL → set as BASE_URL in .env
```

---

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/sessions` | Create new meetup session |
| GET | `/api/sessions/:id` | Get session state |
| GET | `/api/autocomplete?input=` | Address autocomplete |
| POST | `/api/sessions/:id/participants` | Submit user preferences |
| POST | `/api/sessions/:id/compute` | Compute midpoint + find restaurants |
| POST | `/api/sessions/:id/vote` | Cast a vote |
| POST | `/api/sessions/:id/finalise` | Lock in the winner |

---

## Telegram Commands

| Command | Description |
|---|---|
| `/meetup` | Start a new meetup session |
| `/results <sessionId>` | Check current vote standings |

---

## Using OpenStreetMap (Free Alternative)

Set `USE_OSM=true` in `.env` to use Nominatim for geocoding (no API key needed). Restaurant search will be limited — recommend Google for production.

---

## Optional Enhancements (Pre-wired)

- **Yelp Fusion API**: Set `YELP_API_KEY` for richer dish/review data
- **Telegram WebApp**: Works as a Mini App — set the bot's web_app URL via BotFather
- **Auto-expiry**: Sessions expire after 24h via MongoDB TTL index

---

## Tech Stack

- **Bot**: `node-telegram-bot-api`
- **Backend**: Express + Socket.IO + Mongoose
- **Database**: MongoDB (+ optional Redis)
- **Maps**: Google Maps JS API + Places + Geocoding + Distance Matrix
- **Frontend**: Vanilla JS + CSS (no framework — fast mobile load)
- **Realtime**: Socket.IO (WebSocket)
