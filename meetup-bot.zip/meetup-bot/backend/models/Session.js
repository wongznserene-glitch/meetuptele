// backend/models/Session.js
const mongoose = require('mongoose');

const ParticipantSchema = new mongoose.Schema({
  telegramId: String,
  telegramUsername: String,
  name: String,
  location: {
    address: String,
    lat: Number,
    lng: Number,
  },
  availabilityTimes: [String],         // e.g. ["18:30", "19:00"]
  cuisinePreferences: [String],         // e.g. ["Chinese", "Vietnamese"]
  budget: { type: String, enum: ['$', '$$', '$$$'], default: '$$' },
  submittedAt: { type: Date, default: Date.now },
});

const VoteSchema = new mongoose.Schema({
  telegramId: String,
  name: String,
  placeId: String,                      // Google Place ID or internal ID
  votedAt: { type: Date, default: Date.now },
});

const RestaurantSchema = new mongoose.Schema({
  placeId: String,
  name: String,
  address: String,
  lat: Number,
  lng: Number,
  rating: Number,
  priceLevel: Number,                   // 1–4 maps to $–$$$$
  cuisine: String,
  photoUrl: String,
  mapsUrl: String,
  topDishes: [String],
  reviewSummary: String,
  votes: { type: Number, default: 0 },
});

const SessionSchema = new mongoose.Schema({
  sessionId: { type: String, required: true, unique: true, index: true },
  chatId: String,                        // Telegram chat/group ID
  createdBy: String,                     // Telegram user ID who initiated
  status: {
    type: String,
    enum: ['collecting', 'computing', 'voting', 'completed'],
    default: 'collecting',
  },
  participants: [ParticipantSchema],
  votes: [VoteSchema],
  midpoint: { lat: Number, lng: Number },
  restaurants: [RestaurantSchema],
  winner: RestaurantSchema,
  createdAt: { type: Date, default: Date.now },
  expiresAt: {
    type: Date,
    default: () => new Date(Date.now() + 24 * 60 * 60 * 1000),
  },
});

// Auto-expire sessions
SessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('Session', SessionSchema);
