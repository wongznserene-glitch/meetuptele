// backend/routes/api.js
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const Session = require('../models/Session');
const { geocodeAddress, autocompleteAddress, computeMidpoint, getTravelTimes } = require('../services/locationService');
const { searchRestaurants, priceLevelToString } = require('../services/restaurantService');

// ─── Create a new session (called by Telegram bot) ───────────────────────────
router.post('/sessions', async (req, res) => {
  try {
    const { chatId, createdBy } = req.body;
    const sessionId = uuidv4().replace(/-/g, '').slice(0, 12);
    const session = await Session.create({ sessionId, chatId, createdBy });
    res.json({ sessionId, url: `${process.env.BASE_URL}/meetup/${sessionId}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Get session info ─────────────────────────────────────────────────────────
router.get('/sessions/:sessionId', async (req, res) => {
  try {
    const session = await Session.findOne({ sessionId: req.params.sessionId });
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Address autocomplete proxy ───────────────────────────────────────────────
router.get('/autocomplete', async (req, res) => {
  try {
    const { input, sessionToken } = req.query;
    const results = await autocompleteAddress(input, sessionToken);
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Submit participant details ───────────────────────────────────────────────
router.post('/sessions/:sessionId/participants', async (req, res) => {
  try {
    const session = await Session.findOne({ sessionId: req.params.sessionId });
    if (!session) return res.status(404).json({ error: 'Session not found' });
    if (session.status !== 'collecting') {
      return res.status(400).json({ error: 'Session is no longer accepting participants' });
    }

    const { telegramId, name, location, availabilityTimes, cuisinePreferences, budget } = req.body;

    // Geocode address if only text was given
    let geo = location;
    if (location.address && (!location.lat || !location.lng)) {
      const coords = await geocodeAddress(location.address);
      geo = { address: coords.formattedAddress, lat: coords.lat, lng: coords.lng };
    }

    // Remove existing entry for this user (re-submit)
    session.participants = session.participants.filter(
      (p) => p.telegramId !== telegramId
    );
    session.participants.push({ telegramId, name, location: geo, availabilityTimes, cuisinePreferences, budget });
    await session.save();

    // Emit update via Socket.IO
    req.app.get('io').to(req.params.sessionId).emit('participantJoined', {
      name,
      count: session.participants.length,
    });

    res.json({ success: true, participantCount: session.participants.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Compute midpoint + fetch restaurants ────────────────────────────────────
router.post('/sessions/:sessionId/compute', async (req, res) => {
  try {
    const session = await Session.findOne({ sessionId: req.params.sessionId });
    if (!session) return res.status(404).json({ error: 'Session not found' });
    if (!session.participants.length) {
      return res.status(400).json({ error: 'No participants yet' });
    }

    session.status = 'computing';
    await session.save();

    // Compute midpoint
    const locs = session.participants
      .filter((p) => p.location?.lat)
      .map((p) => ({ lat: p.location.lat, lng: p.location.lng }));

    const midpoint = computeMidpoint(locs);
    session.midpoint = midpoint;

    // Aggregate preferred cuisines + budgets
    const cuisines = [...new Set(session.participants.flatMap((p) => p.cuisinePreferences || []))];
    const budgets = [...new Set(session.participants.map((p) => p.budget).filter(Boolean))];

    // Find restaurants
    const restaurants = await searchRestaurants({ midpoint, cuisines, budgets, limit: 6 });
    session.restaurants = restaurants;
    session.status = 'voting';
    await session.save();

    req.app.get('io').to(req.params.sessionId).emit('restaurantsReady', { restaurants, midpoint });

    res.json({ midpoint, restaurants });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Cast a vote ──────────────────────────────────────────────────────────────
router.post('/sessions/:sessionId/vote', async (req, res) => {
  try {
    const session = await Session.findOne({ sessionId: req.params.sessionId });
    if (!session) return res.status(404).json({ error: 'Session not found' });
    if (session.status !== 'voting') {
      return res.status(400).json({ error: 'Voting is not active' });
    }

    const { telegramId, name, placeId } = req.body;

    // One vote per user — remove previous
    session.votes = session.votes.filter((v) => v.telegramId !== telegramId);
    session.votes.push({ telegramId, name, placeId });

    // Tally votes on restaurant list
    for (const r of session.restaurants) {
      r.votes = session.votes.filter((v) => v.placeId === r.placeId).length;
    }

    await session.save();

    // Build vote tally to broadcast
    const tally = session.restaurants.map((r) => ({ placeId: r.placeId, votes: r.votes }));
    req.app.get('io').to(req.params.sessionId).emit('voteUpdate', { tally, voterName: name });

    res.json({ success: true, tally });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Finalise vote + get winner ───────────────────────────────────────────────
router.post('/sessions/:sessionId/finalise', async (req, res) => {
  try {
    const session = await Session.findOne({ sessionId: req.params.sessionId });
    if (!session) return res.status(404).json({ error: 'Session not found' });

    // Find restaurant with most votes
    const winner = session.restaurants.reduce((best, r) => (r.votes > (best?.votes || -1) ? r : best), null);
    if (!winner) return res.status(400).json({ error: 'No votes yet' });

    // Get travel times to winner from all participant origins
    const origins = session.participants.filter((p) => p.location?.lat).map((p) => p.location);
    const travelTimes = await getTravelTimes(origins, { lat: winner.lat, lng: winner.lng });

    session.winner = winner;
    session.status = 'completed';
    await session.save();

    req.app.get('io').to(req.params.sessionId).emit('meetupConfirmed', { winner, travelTimes });

    res.json({ winner, travelTimes });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
