// backend/services/locationService.js
const axios = require('axios');

const GOOGLE_KEY = process.env.GOOGLE_MAPS_API_KEY;
const USE_OSM = process.env.USE_OSM === 'true';

/**
 * Geocode an address string → { lat, lng, formattedAddress }
 */
async function geocodeAddress(address) {
  if (USE_OSM) {
    const res = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: { q: address, format: 'json', limit: 1 },
      headers: { 'User-Agent': 'MeetupBot/1.0' },
    });
    if (!res.data.length) throw new Error('Location not found');
    return {
      lat: parseFloat(res.data[0].lat),
      lng: parseFloat(res.data[0].lon),
      formattedAddress: res.data[0].display_name,
    };
  }

  const res = await axios.get('https://maps.googleapis.com/maps/api/geocode/json', {
    params: { address, key: GOOGLE_KEY },
  });
  if (!res.data.results.length) throw new Error('Location not found');
  const r = res.data.results[0];
  return {
    lat: r.geometry.location.lat,
    lng: r.geometry.location.lng,
    formattedAddress: r.formatted_address,
  };
}

/**
 * Autocomplete addresses (Google Places Autocomplete)
 */
async function autocompleteAddress(input, sessionToken) {
  if (USE_OSM) {
    const res = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: { q: input, format: 'json', limit: 5 },
      headers: { 'User-Agent': 'MeetupBot/1.0' },
    });
    return res.data.map((r) => ({
      description: r.display_name,
      placeId: r.place_id,
    }));
  }

  const res = await axios.get(
    'https://maps.googleapis.com/maps/api/place/autocomplete/json',
    { params: { input, key: GOOGLE_KEY, sessiontoken: sessionToken } }
  );
  return res.data.predictions.map((p) => ({
    description: p.description,
    placeId: p.place_id,
  }));
}

/**
 * Compute weighted geographic midpoint from an array of { lat, lng } objects
 */
function computeMidpoint(locations) {
  if (!locations.length) throw new Error('No locations provided');
  const n = locations.length;
  const lat = locations.reduce((s, l) => s + l.lat, 0) / n;
  const lng = locations.reduce((s, l) => s + l.lng, 0) / n;
  return { lat, lng };
}

/**
 * Haversine distance in km between two { lat, lng } points
 */
function haversineDistance(a, b) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) *
      Math.cos((b.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

/**
 * Get travel time from Google Distance Matrix (car/foot/transit)
 */
async function getTravelTimes(origins, destination) {
  if (USE_OSM) return null; // OSM doesn't have a free Distance Matrix
  const modes = ['driving', 'walking', 'transit'];
  const results = {};
  const destStr = `${destination.lat},${destination.lng}`;
  const origStr = origins.map((o) => `${o.lat},${o.lng}`).join('|');

  for (const mode of modes) {
    try {
      const res = await axios.get(
        'https://maps.googleapis.com/maps/api/distancematrix/json',
        {
          params: {
            origins: origStr,
            destinations: destStr,
            mode,
            key: GOOGLE_KEY,
          },
        }
      );
      results[mode] = res.data.rows.map((row) => ({
        duration: row.elements[0]?.duration?.text || 'N/A',
        distance: row.elements[0]?.distance?.text || 'N/A',
      }));
    } catch {
      results[mode] = null;
    }
  }
  return results;
}

module.exports = { geocodeAddress, autocompleteAddress, computeMidpoint, haversineDistance, getTravelTimes };
