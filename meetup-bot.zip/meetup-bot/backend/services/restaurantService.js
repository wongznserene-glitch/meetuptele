// backend/services/restaurantService.js
const axios = require('axios');
const { haversineDistance } = require('./locationService');

const GOOGLE_KEY = process.env.GOOGLE_MAPS_API_KEY;
const YELP_KEY = process.env.YELP_API_KEY;

// Map UI cuisine names → Google Places types / keywords
const CUISINE_KEYWORD_MAP = {
  Japanese: 'japanese restaurant',
  Chinese: 'chinese restaurant',
  Korean: 'korean restaurant',
  Italian: 'italian restaurant',
  Thai: 'thai restaurant',
  Indian: 'indian restaurant',
  Mexican: 'mexican restaurant',
  American: 'american restaurant',
  Mediterranean: 'mediterranean restaurant',
  Vietnamese: 'vietnamese restaurant',
  Western: 'western restaurant',
  Seafood: 'seafood restaurant',
};

const PRICE_LEVEL_MAP = { $: 1, '$$': 2, '$$$': 3 };

/**
 * Search restaurants near a midpoint using Google Places Nearby Search
 */
async function searchRestaurants({ midpoint, cuisines = [], budgets = [], limit = 8 }) {
  const keyword = cuisines.length
    ? cuisines.map((c) => CUISINE_KEYWORD_MAP[c] || c).join(' OR ')
    : 'restaurant';

  const maxPrice = budgets.length
    ? Math.max(...budgets.map((b) => PRICE_LEVEL_MAP[b] || 2))
    : 3;

  const res = await axios.get(
    'https://maps.googleapis.com/maps/api/place/nearbysearch/json',
    {
      params: {
        location: `${midpoint.lat},${midpoint.lng}`,
        radius: 1500,
        type: 'restaurant',
        keyword,
        maxprice: maxPrice,
        key: GOOGLE_KEY,
      },
    }
  );

  const places = res.data.results.slice(0, limit);

  // Enrich each place
  const restaurants = await Promise.all(
    places.map(async (p) => {
      const details = await getPlaceDetails(p.place_id);
      const dist = haversineDistance(midpoint, {
        lat: p.geometry.location.lat,
        lng: p.geometry.location.lng,
      });

      return {
        placeId: p.place_id,
        name: p.name,
        address: details.formatted_address || p.vicinity,
        lat: p.geometry.location.lat,
        lng: p.geometry.location.lng,
        rating: p.rating || 0,
        priceLevel: p.price_level || 2,
        cuisine: cuisines[0] || 'Restaurant',
        photoUrl: p.photos?.length
          ? `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photo_reference=${p.photos[0].photo_reference}&key=${GOOGLE_KEY}`
          : null,
        mapsUrl: `https://www.google.com/maps/place/?q=place_id:${p.place_id}`,
        topDishes: details.topDishes || [],
        reviewSummary: details.reviewSummary || '',
        distanceKm: dist.toFixed(2),
        votes: 0,
      };
    })
  );

  // Sort by rating × proximity score
  return restaurants.sort((a, b) => {
    const scoreA = a.rating - a.distanceKm * 0.3;
    const scoreB = b.rating - b.distanceKm * 0.3;
    return scoreB - scoreA;
  });
}

/**
 * Get detailed place information including reviews
 */
async function getPlaceDetails(placeId) {
  try {
    const res = await axios.get(
      'https://maps.googleapis.com/maps/api/place/details/json',
      {
        params: {
          place_id: placeId,
          fields: 'formatted_address,reviews,editorial_summary',
          key: GOOGLE_KEY,
        },
      }
    );
    const result = res.data.result;
    const reviews = result.reviews || [];

    // Extract top dishes from review text (simple keyword extraction)
    const topDishes = extractTopDishes(reviews.map((r) => r.text).join(' '));

    // Summarise reviews (take top 2 positive snippets)
    const reviewSummary = reviews
      .filter((r) => r.rating >= 4)
      .slice(0, 2)
      .map((r) => r.text.split('.')[0])
      .join('. ');

    return {
      formatted_address: result.formatted_address,
      topDishes,
      reviewSummary: reviewSummary || result.editorial_summary?.overview || '',
    };
  } catch {
    return {};
  }
}

/**
 * Very simple dish extractor: look for "the X is great/amazing/must-try" patterns
 */
function extractTopDishes(text) {
  const patterns = [
    /(?:try|must.?try|best|recommend|loved?|amazing|delicious)\s+(?:the\s+)?([a-zA-Z\s]{3,25})/gi,
    /([a-zA-Z\s]{3,25})\s+(?:was|is|were)\s+(?:amazing|great|delicious|fantastic|superb|incredible)/gi,
  ];
  const found = new Set();
  for (const p of patterns) {
    let m;
    while ((m = p.exec(text)) !== null && found.size < 5) {
      const dish = m[1].trim().replace(/\s+/g, ' ');
      if (dish.split(' ').length <= 4) found.add(dish);
    }
  }
  return [...found].slice(0, 2);
}

/**
 * Price level integer → display string
 */
function priceLevelToString(level) {
  return '$'.repeat(Math.min(Math.max(level || 2, 1), 4));
}

module.exports = { searchRestaurants, priceLevelToString };
