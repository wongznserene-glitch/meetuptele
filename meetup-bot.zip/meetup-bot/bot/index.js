// bot/index.js
require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';
const API_BASE = `${BASE_URL}/api`;

if (!BOT_TOKEN) {
  console.error('❌ TELEGRAM_BOT_TOKEN not set in .env');
  process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

// ─── /meetup command ──────────────────────────────────────────────────────────
bot.onText(/\/meetup/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const userName = msg.from.first_name || msg.from.username || 'Someone';

  try {
    const { data } = await axios.post(`${API_BASE}/sessions`, {
      chatId: chatId.toString(),
      createdBy: userId,
    });

    const sessionUrl = data.url;

    await bot.sendMessage(chatId, 
      `🍽️ *${userName} started a meetup!*\n\nTap the link below to pick your location, availability, and cuisine preferences.\n\n📍 [Open Meetup Planner](${sessionUrl})\n\n_Share this link with everyone who's joining._`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [[
            { text: '🗓 Plan Meetup', url: sessionUrl }
          ]]
        }
      }
    );
  } catch (err) {
    console.error('Error creating session:', err.message);
    await bot.sendMessage(chatId, '❌ Could not create meetup session. Please try again.');
  }
});

// ─── /results command — show current results ──────────────────────────────────
bot.onText(/\/results (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const sessionId = match[1].trim();

  try {
    const { data: session } = await axios.get(`${API_BASE}/sessions/${sessionId}`);

    if (session.status === 'collecting') {
      const names = session.participants.map(p => `• ${p.name}`).join('\n') || '(none yet)';
      return bot.sendMessage(chatId,
        `📋 *Meetup in progress*\n\nParticipants so far:\n${names}\n\nStatus: Still collecting responses.`,
        { parse_mode: 'Markdown' }
      );
    }

    if (session.status === 'voting') {
      const top = [...session.restaurants]
        .sort((a, b) => b.votes - a.votes)
        .slice(0, 3)
        .map((r, i) => `${i + 1}. ${r.name} — ${r.votes} vote(s) ⭐${r.rating}`)
        .join('\n');
      return bot.sendMessage(chatId,
        `🗳️ *Voting in progress!*\n\nCurrent standings:\n${top}`,
        { parse_mode: 'Markdown' }
      );
    }

    if (session.status === 'completed' && session.winner) {
      return sendWinnerMessage(chatId, session.winner);
    }

    bot.sendMessage(chatId, 'No results yet.');
  } catch (err) {
    bot.sendMessage(chatId, '❌ Could not fetch results. Check the session ID.');
  }
});

// ─── Called internally after finalise ────────────────────────────────────────
async function sendWinnerMessage(chatId, winner, travelTimes) {
  const price = '$'.repeat(winner.priceLevel || 2);
  const dishes = winner.topDishes?.length ? winner.topDishes.join(', ') : 'Check the menu!';

  let travel = '';
  if (travelTimes) {
    const d = travelTimes.driving?.[0];
    const w = travelTimes.walking?.[0];
    const t = travelTimes.transit?.[0];
    travel = `\n🚗 ${d?.duration || 'N/A'} by car  🚶 ${w?.duration || 'N/A'} walk  🚌 ${t?.duration || 'N/A'} transit`;
  }

  const text = 
`🎉 *Meetup Confirmed!*

🍽️ *${winner.name}*
📍 ${winner.address}
⭐ Rating: ${winner.rating}/5  💰 ${price}
🥘 Top Dishes: ${dishes}${travel}

[📍 View on Google Maps](${winner.mapsUrl})`;

  await bot.sendMessage(chatId, text, {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [[{ text: '🗺 Open in Maps', url: winner.mapsUrl }]]
    }
  });
}

// ─── Export so server can call sendWinnerMessage ──────────────────────────────
module.exports = { bot, sendWinnerMessage };

console.log('🤖 Telegram bot started (polling)');
