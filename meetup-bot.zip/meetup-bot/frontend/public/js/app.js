// frontend/public/js/app.js
'use strict';

// ── State ─────────────────────────────────────────────────────────────────────
const state = {
  sessionId: null,
  telegramId: null,
  userName: null,
  location: null,        // { address, lat, lng }
  selectedTimes: [],
  selectedCuisines: [],
  selectedBudget: '$',
  participants: [],
  restaurants: [],
  midpoint: null,
  myVote: null,
  isHost: false,
  map: null,
  markers: [],
};

// ── Boot ──────────────────────────────────────────────────────────────────────
(function boot() {
  const pathParts = window.location.pathname.split('/');
  state.sessionId = pathParts[pathParts.length - 1];

  // Pull Telegram user from WebApp if available
  if (window.Telegram?.WebApp) {
    const tg = window.Telegram.WebApp;
    tg.ready();
    tg.expand();
    const user = tg.initDataUnsafe?.user;
    if (user) {
      state.telegramId = String(user.id);
      state.userName = user.first_name || user.username || 'You';
    }
  }

  // Fallback: generate a session-local ID
  if (!state.telegramId) {
    state.telegramId = localStorage.getItem('meetup_uid') || ('u' + Math.random().toString(36).slice(2, 9));
    localStorage.setItem('meetup_uid', state.telegramId);
    state.userName = localStorage.getItem('meetup_name') || promptUserName();
  }

  if (!state.sessionId) return showToast('Invalid session link');

  initSocket();
  loadSession();
  bindEvents();
})();

function promptUserName() {
  let name = prompt('Enter your name:') || 'Anonymous';
  localStorage.setItem('meetup_name', name);
  return name;
}

// ── Socket.IO ─────────────────────────────────────────────────────────────────
function initSocket() {
  const socket = io();
  socket.emit('joinSession', state.sessionId);

  socket.on('participantJoined', ({ name, count }) => {
    updateParticipantBadge(count);
    if (name !== state.userName) showToast(`${name} joined!`);
    loadSession(); // refresh participants list
  });

  socket.on('restaurantsReady', ({ restaurants, midpoint }) => {
    state.restaurants = restaurants;
    state.midpoint = midpoint;
    showVotingStep();
  });

  socket.on('voteUpdate', ({ tally, voterName }) => {
    applyVoteTally(tally);
    if (voterName !== state.userName) showToast(`${voterName} voted!`);
  });

  socket.on('meetupConfirmed', ({ winner, travelTimes }) => {
    showCompletedStep(winner, travelTimes);
  });
}

// ── Load session state ────────────────────────────────────────────────────────
async function loadSession() {
  try {
    const data = await apiGet(`/sessions/${state.sessionId}`);
    state.participants = data.participants || [];
    state.isHost = data.createdBy === state.telegramId;

    updateFriendsList();
    updateParticipantBadge(state.participants.length);

    if (data.status === 'voting') {
      state.restaurants = data.restaurants;
      state.midpoint = data.midpoint;
      showVotingStep();
    } else if (data.status === 'completed') {
      showCompletedStep(data.winner, null);
    } else {
      // Show compute button for host once ≥2 participants have submitted
      if (state.isHost && state.participants.length >= 2) {
        document.getElementById('compute-section').classList.remove('hidden');
      }
    }
  } catch (err) {
    showToast('Failed to load session');
  }
}

// ── Bind UI events ────────────────────────────────────────────────────────────
function bindEvents() {
  // Location autocomplete
  const locInput = document.getElementById('location-input');
  let autoDebounce;
  locInput.addEventListener('input', () => {
    clearTimeout(autoDebounce);
    autoDebounce = setTimeout(() => fetchAutocomplete(locInput.value), 300);
  });

  // GPS button
  document.getElementById('gps-btn').addEventListener('click', getGPS);

  // Update location (just stores locally)
  document.getElementById('update-location-btn').addEventListener('click', confirmLocation);

  // Time chips
  document.querySelectorAll('.time-chip').forEach(btn => {
    btn.addEventListener('click', () => toggleChip(btn, state.selectedTimes, btn.dataset.time));
  });

  // Cuisine chips
  document.querySelectorAll('.cuisine-chip').forEach(btn => {
    btn.addEventListener('click', () => toggleChip(btn, state.selectedCuisines, btn.dataset.cuisine));
  });

  // Budget chips
  document.querySelectorAll('.budget-chip').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.budget-chip').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.selectedBudget = btn.dataset.budget;
    });
  });

  // Submit
  document.getElementById('submit-btn').addEventListener('click', submitParticipant);

  // Compute restaurants
  document.getElementById('compute-btn').addEventListener('click', computeRestaurants);

  // Finalise vote
  document.getElementById('finalise-btn').addEventListener('click', finaliseVote);
}

// ── Autocomplete ──────────────────────────────────────────────────────────────
async function fetchAutocomplete(input) {
  if (input.length < 3) return hideAutocomplete();
  try {
    const results = await apiGet(`/autocomplete?input=${encodeURIComponent(input)}&sessionToken=${state.telegramId}`);
    showAutocompleteList(results);
  } catch {}
}

function showAutocompleteList(results) {
  const list = document.getElementById('autocomplete-list');
  list.innerHTML = '';
  if (!results.length) return list.classList.add('hidden');
  results.forEach(r => {
    const el = document.createElement('div');
    el.className = 'autocomplete-item';
    el.textContent = r.description;
    el.addEventListener('click', () => {
      document.getElementById('location-input').value = r.description;
      state.location = { address: r.description, lat: null, lng: null };
      hideAutocomplete();
    });
    list.appendChild(el);
  });
  list.classList.remove('hidden');
}

function hideAutocomplete() {
  document.getElementById('autocomplete-list').classList.add('hidden');
}

// ── GPS ───────────────────────────────────────────────────────────────────────
function getGPS() {
  if (!navigator.geolocation) return showToast('Geolocation not supported');
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const { latitude: lat, longitude: lng } = pos.coords;
      state.location = { address: `${lat.toFixed(5)}, ${lng.toFixed(5)}`, lat, lng };
      document.getElementById('location-input').value = state.location.address;
      showToast('📍 Location captured!');
    },
    () => showToast('Could not get location')
  );
}

function confirmLocation() {
  const val = document.getElementById('location-input').value.trim();
  if (!val) return showToast('Please enter your location');
  if (!state.location) state.location = { address: val };
  showToast('📍 Location set!');
}

// ── Chip Toggle ───────────────────────────────────────────────────────────────
function toggleChip(btn, arr, value) {
  const idx = arr.indexOf(value);
  if (idx === -1) {
    arr.push(value);
    btn.classList.add('active');
    btn.dataset.count = '1';
  } else {
    arr.splice(idx, 1);
    btn.classList.remove('active');
    delete btn.dataset.count;
  }
}

// ── Submit participant ────────────────────────────────────────────────────────
async function submitParticipant() {
  if (!state.location?.address) return showToast('Please set your location first');
  if (!state.selectedTimes.length) return showToast('Pick at least one time slot');

  const btn = document.getElementById('submit-btn');
  btn.textContent = 'Submitting…';
  btn.disabled = true;

  try {
    await apiPost(`/sessions/${state.sessionId}/participants`, {
      telegramId: state.telegramId,
      name: state.userName,
      location: state.location,
      availabilityTimes: state.selectedTimes,
      cuisinePreferences: state.selectedCuisines,
      budget: state.selectedBudget,
    });

    showToast('✅ You\'re in!');
    btn.textContent = 'Updated ✓';

    // Show compute button for host
    if (state.isHost) {
      document.getElementById('compute-section').classList.remove('hidden');
    }
  } catch (err) {
    btn.textContent = 'I\'m in! 🎉';
    btn.disabled = false;
    showToast('Submission failed. Try again.');
  }
}

// ── Compute restaurants ───────────────────────────────────────────────────────
async function computeRestaurants() {
  showStep('step-computing');
  try {
    const data = await apiPost(`/sessions/${state.sessionId}/compute`, {});
    state.restaurants = data.restaurants;
    state.midpoint = data.midpoint;
    showVotingStep();
  } catch (err) {
    showToast('Failed to compute: ' + (err.message || ''));
    showStep('step-collect');
  }
}

// ── Voting step ───────────────────────────────────────────────────────────────
function showVotingStep() {
  showStep('step-voting');
  renderRestaurants();
  if (state.map && state.midpoint) dropMapMarkers();
}

function renderRestaurants() {
  const list = document.getElementById('restaurant-list');
  list.innerHTML = '';
  const maxVotes = Math.max(1, ...state.restaurants.map(r => r.votes || 0));

  state.restaurants.forEach(r => {
    const priceDots = '$'.repeat(r.priceLevel || 2);
    const voted = state.myVote === r.placeId;
    const card = document.createElement('div');
    card.className = `restaurant-card${voted ? ' voted' : ''}`;
    card.dataset.placeId = r.placeId;

    const photoHtml = r.photoUrl
      ? `<img class="restaurant-photo" src="${escHtml(r.photoUrl)}" alt="${escHtml(r.name)}" loading="lazy"/>`
      : `<div class="restaurant-photo-placeholder">🍽️</div>`;

    const dishes = r.topDishes?.length
      ? `<div class="restaurant-dishes"><strong>Top dishes:</strong> ${escHtml(r.topDishes.join(', '))}</div>`
      : '';

    const voteBarPct = maxVotes > 0 ? ((r.votes || 0) / maxVotes * 100).toFixed(0) : 0;

    card.innerHTML = `
      ${photoHtml}
      <div class="restaurant-body">
        <div class="restaurant-row1">
          <div class="restaurant-name">${escHtml(r.name)}</div>
          <div class="restaurant-price">${priceDots}</div>
        </div>
        <div class="restaurant-meta">
          <div class="restaurant-rating"><span class="star">★</span> ${r.rating || 'N/A'}</div>
          <span>•</span>
          <span>${r.distanceKm} km away</span>
          <span>•</span>
          <span>${escHtml(r.cuisine || '')}</span>
        </div>
        ${dishes}
        <div class="restaurant-vote-row">
          <div class="vote-bar-wrap"><div class="vote-bar" style="width:${voteBarPct}%"></div></div>
          <div class="vote-count">${r.votes || 0} vote${(r.votes || 0) !== 1 ? 's' : ''}</div>
        </div>
      </div>
    `;

    card.addEventListener('click', () => castVote(r.placeId, card));
    list.appendChild(card);
  });
}

async function castVote(placeId, card) {
  try {
    await apiPost(`/sessions/${state.sessionId}/vote`, {
      telegramId: state.telegramId,
      name: state.userName,
      placeId,
    });
    state.myVote = placeId;
    document.querySelectorAll('.restaurant-card').forEach(c => c.classList.remove('voted'));
    card.classList.add('voted');
    showToast('Vote cast! 🗳️');
  } catch (err) {
    showToast('Could not vote. Try again.');
  }
}

function applyVoteTally(tally) {
  const maxVotes = Math.max(1, ...tally.map(t => t.votes));
  tally.forEach(({ placeId, votes }) => {
    const card = document.querySelector(`[data-place-id="${placeId}"]`);
    if (!card) return;
    card.querySelector('.vote-count').textContent = `${votes} vote${votes !== 1 ? 's' : ''}`;
    const pct = ((votes / maxVotes) * 100).toFixed(0);
    card.querySelector('.vote-bar').style.width = `${pct}%`;
  });
}

async function finaliseVote() {
  try {
    const data = await apiPost(`/sessions/${state.sessionId}/finalise`, {});
    showCompletedStep(data.winner, data.travelTimes);
  } catch (err) {
    showToast('Could not finalise. Try again.');
  }
}

// ── Completed step ────────────────────────────────────────────────────────────
function showCompletedStep(winner, travelTimes) {
  showStep('step-completed');
  renderWinner(winner, travelTimes);
}

function renderWinner(w, travelTimes) {
  const price = '$'.repeat(w.priceLevel || 2);
  const container = document.getElementById('winner-card');

  let travelHtml = '';
  if (travelTimes) {
    const d = travelTimes.driving?.[0];
    const wk = travelTimes.walking?.[0];
    const t = travelTimes.transit?.[0];
    travelHtml = `
      <div class="winner-travel">
        ${d ? `<div class="travel-row"><span class="travel-icon">🚗</span> ${d.duration} by car (${d.distance})</div>` : ''}
        ${wk ? `<div class="travel-row"><span class="travel-icon">🚶</span> ${wk.duration} walk (${wk.distance})</div>` : ''}
        ${t ? `<div class="travel-row"><span class="travel-icon">🚌</span> ${t.duration} by transit</div>` : ''}
      </div>`;
  }

  const photoHtml = w.photoUrl
    ? `<img class="winner-photo" src="${escHtml(w.photoUrl)}" alt="${escHtml(w.name)}" />`
    : `<div class="restaurant-photo-placeholder" style="height:180px">🏆</div>`;

  container.innerHTML = `
    ${photoHtml}
    <div class="winner-info">
      <div class="winner-name">${escHtml(w.name)}</div>
      <div class="winner-address">📍 ${escHtml(w.address)}</div>
      <div class="winner-stats">
        <div class="winner-stat">
          <span class="winner-stat-label">Rating</span>
          <span class="winner-stat-value">⭐ ${w.rating || 'N/A'}</span>
        </div>
        <div class="winner-stat">
          <span class="winner-stat-label">Price</span>
          <span class="winner-stat-value">${price}</span>
        </div>
        <div class="winner-stat">
          <span class="winner-stat-label">Votes</span>
          <span class="winner-stat-value">🗳️ ${w.votes || 0}</span>
        </div>
      </div>
      ${travelHtml}
    </div>
    <a class="winner-maps-btn" href="${escHtml(w.mapsUrl)}" target="_blank" rel="noopener">📍 Open in Google Maps</a>
  `;
}

// ── Google Maps integration ───────────────────────────────────────────────────
window.initMap = function () {
  state.map = new google.maps.Map(document.getElementById('map-container'), {
    zoom: 14,
    center: { lat: 1.3521, lng: 103.8198 }, // default Singapore
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: false,
  });
  if (state.midpoint) dropMapMarkers();
};

function dropMapMarkers() {
  if (!state.map) return;
  state.markers.forEach(m => m.setMap(null));
  state.markers = [];

  const mid = state.midpoint;
  state.map.setCenter(mid);

  // Midpoint marker
  const midMarker = new google.maps.Marker({
    position: mid,
    map: state.map,
    icon: { url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png' },
    title: 'Midpoint',
  });
  state.markers.push(midMarker);

  // Restaurant markers
  state.restaurants.forEach(r => {
    const m = new google.maps.Marker({
      position: { lat: r.lat, lng: r.lng },
      map: state.map,
      icon: { url: 'https://maps.google.com/mapfiles/ms/icons/restaurant.png' },
      title: r.name,
    });
    state.markers.push(m);
  });

  // Participant markers
  state.participants.forEach(p => {
    if (!p.location?.lat) return;
    const m = new google.maps.Marker({
      position: { lat: p.location.lat, lng: p.location.lng },
      map: state.map,
      icon: { url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png' },
      title: p.name,
    });
    state.markers.push(m);
  });
}

// ── Friends list rendering ────────────────────────────────────────────────────
function updateFriendsList() {
  const list = document.getElementById('friends-list');
  const countEl = document.getElementById('friend-count');
  countEl.textContent = state.participants.length;

  if (!state.participants.length) {
    list.innerHTML = '<p class="empty-friends">No one yet — share the link!</p>';
    return;
  }

  list.innerHTML = state.participants.map(p => `
    <div class="friend-item">
      <div class="friend-avatar">${(p.name || 'A')[0].toUpperCase()}</div>
      <div class="friend-info">
        <div class="friend-name">${escHtml(p.name || 'Anonymous')}</div>
        <div class="friend-location">📍 ${escHtml(p.location?.address || 'Unknown')}</div>
      </div>
      <div class="friend-icons">
        <div class="friend-icon-btn ${p.location?.lat ? 'active' : ''}" title="Location">📍</div>
        <div class="friend-icon-btn ${p.availabilityTimes?.length ? 'active' : ''}" title="Availability">🕐</div>
      </div>
    </div>
  `).join('');
}

function updateParticipantBadge(count) {
  const badge = document.getElementById('participant-badge');
  const countEl = document.getElementById('participant-count');
  badge.classList.toggle('hidden', count === 0);
  countEl.textContent = count;
}

// ── Step switcher ─────────────────────────────────────────────────────────────
function showStep(id) {
  document.querySelectorAll('.step').forEach(s => {
    s.classList.toggle('active', s.id === id);
    s.classList.toggle('hidden', s.id !== id);
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── Toast ─────────────────────────────────────────────────────────────────────
let toastTimer;
function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2800);
}

// ── API helpers ───────────────────────────────────────────────────────────────
async function apiGet(path) {
  const res = await fetch('/api' + path);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function apiPost(path, body) {
  const res = await fetch('/api' + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
